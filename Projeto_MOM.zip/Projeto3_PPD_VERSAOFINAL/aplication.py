import paho.mqtt.client as mqtt
import random
import time
import threading
import tkinter as tk
from tkinter import messagebox

BROKER = "localhost"
PORT = 1883

class Sensor:
    def __init__(self, nome, parametro, min_val, max_val, equipamento, unidade):
        self.nome = nome
        self.parametro = parametro
        self.min_val = min_val
        self.max_val = max_val
        self.equipamento = equipamento
        self.client = equipamento.client  #usa o cliente MQTT do equipamento
        self.unidade = unidade  #unidade de medida
    
    def gerar_dados(self):
        while self.equipamento.ligado:
            valor = random.uniform(self.min_val - 5, self.max_val + 5)
            print(f"{self.equipamento.nome}: {self.parametro} = {valor:.2f} {self.unidade}")
            if valor <= self.min_val or valor >= self.max_val:
                alerta = f"Alerta! {self.parametro} fora dos limites ({valor:.2f} {self.unidade})"
                self.client.publish(f"equipamentos/{self.equipamento.nome}/{self.parametro}", alerta)
                self.equipamento.gerenciador.add_alerta(self.equipamento.nome, alerta)
            time.sleep(2)

#classe equipamento
class Equipamento:
    def __init__(self, nome, parametro, min_val, max_val, unidade, gerenciador):
        self.nome = nome
        self.ligado = False
        self.client = mqtt.Client()
        self.client.connect(BROKER, PORT, 60)
        self.gerenciador = gerenciador
        self.sensor = Sensor(nome, parametro, min_val, max_val, self, unidade)  #um único sensor por equipamento
    
    def ligar(self):
        self.ligado = True
        print(f"{self.nome} ligado.")
        threading.Thread(target=self.sensor.gerar_dados, daemon=True).start()
    
    def desligar(self):
        self.ligado = False
        print(f"{self.nome} desligado.")

class GerenciadorEquipamentos:
    def __init__(self, root):
        self.client = mqtt.Client()
        self.client.on_message = self.on_message
        self.client.connect(BROKER, PORT, 60)
        
        self.equipamentos = []
        
        threading.Thread(target=self.client.loop_start, daemon=True).start()
        
        self.root = root
        self.root.title("Gerenciador de Equipamentos")
        self.root.protocol("WM_DELETE_WINDOW", self.fechar_aplicacao)
        
        #mudando as cores de fundo para um estilo mais moderno
        self.root.configure(bg="#1f1f1f")  # Cor de fundo da janela
        
        #label com fundo escuro e texto claro
        self.label = tk.Label(root, text="Equipamentos monitorados:", font=("Helvetica", 14, "bold"), fg="#ffffff", bg="#1f1f1f", pady=10)
        self.label.pack(pady=5)
        
        #adicionando botões para cada equipamento de forma visualmente atraente
        self.equipamento_buttons_frame = tk.Frame(root, bg="#1f1f1f")
        self.equipamento_buttons_frame.pack(pady=10)
        
        #label de alertas
        self.alert_label = tk.Label(root, text="Alertas:", font=("Helvetica", 14, "bold"), fg="#ffffff", bg="#1f1f1f", pady=10)
        self.alert_label.pack(pady=5)
        
        #scrollbar
        self.scrollbar = tk.Scrollbar(root)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y, padx=5)
        
        #listbox de alertas com fundo escuro e texto em branco
        self.alert_listbox = tk.Listbox(root, width=50, height=10, font=("Helvetica", 12), yscrollcommand=self.scrollbar.set, bg="#2d2d2d", fg="#ffffff")
        self.alert_listbox.pack(pady=5)
        
        self.scrollbar.config(command=self.alert_listbox.yview)
        
        #botão Desligar com cores fortes
        self.desligar_button = tk.Button(root, text="Desligar Equipamento", font=("Helvetica", 14, "bold"), bg="#e74c3c", fg="white", command=self.desligar_equipamento, relief="raised", bd=5, activebackground="#c0392b", activeforeground="white")
        self.desligar_button.pack(pady=15)
        
        #botão Ligar com cores vibrantes
        self.ligar_button = tk.Button(root, text="Ligar Equipamento", font=("Helvetica", 14, "bold"), bg="#2ecc71", fg="white", command=self.ligar_equipamento, relief="raised", bd=5, activebackground="#27ae60", activeforeground="white")
        self.ligar_button.pack(pady=15)
    
    def adicionar_equipamento(self, equipamento):
        self.equipamentos.append(equipamento)
        
        #Criar um botão para cada equipamento
        equipamento_button = tk.Button(self.equipamento_buttons_frame, text=equipamento.nome, font=("Helvetica", 12), bg="#34495e", fg="white", relief="raised", bd=5, activebackground="#2c3e50", command=lambda e=equipamento: self.selecionar_equipamento(e))
        equipamento_button.pack(pady=5, fill=tk.X)
    
    def selecionar_equipamento(self, equipamento):
        #alterar visualmente a seleção do equipamento
        for button in self.equipamento_buttons_frame.winfo_children():
            button.config(bg="#34495e")
        
        equipamento_button = next(button for button in self.equipamento_buttons_frame.winfo_children() if button.cget("text") == equipamento.nome)
        equipamento_button.config(bg="#16a085")  #cor de destaque para o equipamento selecionado
        
        self.equipamento_selecionado = equipamento
        print(f"{equipamento.nome} selecionado.")
    
    def desligar_equipamento(self):
        if hasattr(self, 'equipamento_selecionado'):
            equip_nome = self.equipamento_selecionado.nome
            for equip in self.equipamentos:
                if equip.nome == equip_nome:
                    equip.desligar()
                    messagebox.showinfo("Desligado", f"{equip_nome} desligado com sucesso.")
                    break
    
    def ligar_equipamento(self):
        if hasattr(self, 'equipamento_selecionado'):
            equip_nome = self.equipamento_selecionado.nome
            for equip in self.equipamentos:
                if equip.nome == equip_nome:
                    equip.ligar()
                    messagebox.showinfo("Ligado", f"{equip_nome} ligado com sucesso.")
                    break
    
    def on_message(self, client, userdata, msg):
        alerta = msg.payload.decode()
        print(f"Mensagem recebida no tópico {msg.topic}: {alerta}")
        self.add_alerta(msg.topic.split("/")[-2], alerta)
    
    def add_alerta(self, equipamento, alerta):
        self.root.after(0, lambda: self.alert_listbox.insert(tk.END, f"{equipamento}: {alerta}"))
        self.root.after(0, lambda: self.alert_listbox.yview_scroll(1, "units"))
    
    def fechar_aplicacao(self):
        self.client.loop_stop()
        self.root.destroy()

# função para inicializar e adicionar os sensores ao Gerenciador de Equipamentos
def iniciar_sensores():
    equipamentos_data = [
        ("Equipamento1", "temperatura", 10, 30, "°C"),
        ("Equipamento2", "umidade", 40, 70, "%"),
        ("Equipamento3", "pressao", 1050, 1100, "hPa")
    ]
    
    root = tk.Tk()
    ge = GerenciadorEquipamentos(root)
    
    for nome, param, min_val, max_val, unidade in equipamentos_data:
        equipamento = Equipamento(nome, param, min_val, max_val, unidade, ge)
        ge.adicionar_equipamento(equipamento)
        equipamento.ligar()
    
    root.mainloop()

#executando a aplicação
if __name__ == "__main__":
    iniciar_sensores()
